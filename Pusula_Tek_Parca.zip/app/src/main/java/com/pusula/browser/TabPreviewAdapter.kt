
package com.pusula.browser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TabPreviewAdapter(
    private val tabs: List<TabModel>,
    private val onTabClick: (TabModel) -> Unit,
    private val onTabClose: (TabModel) -> Unit
) : RecyclerView.Adapter<TabPreviewAdapter.ViewHolder>() {

    class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val preview: ImageView = v.findViewById(R.id.tabPreviewImage)
        val title: TextView = v.findViewById(R.id.tabTitle)
        val close: ImageView = v.findViewById(R.id.tabClose)
        val privateBadge: TextView = v.findViewById(R.id.privateBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.tab_preview_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tab = tabs[position]
        holder.title.text = tab.title
        if (tab.bitmap != null) holder.preview.setImageBitmap(tab.bitmap) else holder.preview.setImageResource(R.drawable.ic_home)
        holder.privateBadge.visibility = if (tab.isPrivate) View.VISIBLE else View.GONE
        holder.itemView.setOnClickListener { onTabClick(tab) }
        holder.close.setOnClickListener { onTabClose(tab) }
    }

    override fun getItemCount() = tabs.size
}
