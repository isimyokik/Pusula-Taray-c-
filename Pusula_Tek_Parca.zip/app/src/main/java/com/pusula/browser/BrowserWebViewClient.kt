
package com.pusula.browser

import android.graphics.Bitmap
import android.webkit.*

class BrowserWebViewClient(
    private val onPreviewNeeded: (Bitmap?) -> Unit
) : WebViewClient() {

    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        // Reklam engelleme burada
        if (AdBlocker.isAdRequest(request)) {
            return AdBlocker.createEmptyResponse()
        }
        return super.shouldInterceptRequest(view, request)
    }

    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        TabManager.getCurrentTab()?.let {
            it.url = url ?: ""
            it.isLoading = true
        }
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        TabManager.getCurrentTab()?.let {
            it.isLoading = false
            it.title = view?.title ?: "Pusula"
        }
        view?.let {
            // Sekme önizlemesi için snapshot al
            val preview = TabManager.capturePreview(it)
            TabManager.updatePreview(TabManager.currentTabId ?: "", preview)
            onPreviewNeeded(preview)
        }
    }
}
