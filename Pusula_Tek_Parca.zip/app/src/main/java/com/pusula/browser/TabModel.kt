
package com.pusula.browser

import android.graphics.Bitmap

data class TabModel(
    val id: String,
    var title: String = "Yeni Sekme",
    var url: String = "",
    var bitmap: Bitmap? = null, // Önizleme için ekran görüntüsü
    var isPrivate: Boolean = false,
    var isLoading: Boolean = false
)
