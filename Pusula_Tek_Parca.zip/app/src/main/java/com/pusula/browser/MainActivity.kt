
package com.pusula.browser

import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebSettings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var tabPreviewOverlay: View
    private lateinit var tabRecycler: RecyclerView
    private lateinit var vpnButton: TextView
    private lateinit var adBlockButton: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        tabPreviewOverlay = findViewById(R.id.tabPreviewOverlay)
        tabRecycler = findViewById(R.id.tabRecycler)
        vpnButton = findViewById(R.id.vpnButton)
        adBlockButton = findViewById(R.id.adBlockButton)

        setupWebView()
        setupTabs()
        setupVpn()
        setupAdBlock()

        if (TabManager.tabs.isEmpty()) {
            TabManager.createNewTab()
        }
        loadHome()
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            // Gizlilik sekmesi için ayrı ayar
        }
        webView.webViewClient = BrowserWebViewClient { preview ->
            // Önizleme güncellendi
        }
    }

    private fun setupTabs() {
        tabRecycler.layoutManager = GridLayoutManager(this, 2)
        tabRecycler.adapter = TabPreviewAdapter(TabManager.tabs,
            onTabClick = { tab ->
                TabManager.currentTabId = tab.id
                tabPreviewOverlay.visibility = View.GONE
                webView.loadUrl(tab.url.ifEmpty { "https://www.google.com" })
                if (tab.isPrivate) {
                    webView.clearHistory()
                    // Gizlilik modu UI
                }
            },
            onTabClose = { tab ->
                TabManager.tabs.remove(tab)
                tabRecycler.adapter?.notifyDataSetChanged()
                if (TabManager.tabs.isEmpty()) TabManager.createNewTab()
            }
        )

        findViewById<View>(R.id.tabCountButton).setOnClickListener {
            // ÖNİZLEME AÇ - İSTEDİĞİN ÖZELLİK BURASI
            TabManager.getCurrentTab()?.let {
                val bmp = TabManager.capturePreview(webView)
                TabManager.updatePreview(it.id, bmp)
            }
            tabRecycler.adapter?.notifyDataSetChanged()
            tabPreviewOverlay.visibility = View.VISIBLE
        }

        findViewById<View>(R.id.newTabButton).setOnClickListener {
            TabManager.createNewTab()
            tabRecycler.adapter?.notifyDataSetChanged()
            loadHome()
            tabPreviewOverlay.visibility = View.GONE
        }

        findViewById<View>(R.id.newPrivateTabButton).setOnClickListener {
            TabManager.createNewTab(isPrivate = true)
            tabRecycler.adapter?.notifyDataSetChanged()
            Toast.makeText(this, "Gizlilik sekmesi açıldı - Geçmiş kaydedilmiyor", Toast.LENGTH_SHORT).show()
            loadHome()
            tabPreviewOverlay.visibility = View.GONE
        }
    }

    private fun setupVpn() {
        updateVpnUi()
        vpnButton.setOnClickListener {
            // VPN Seçici Dialog
            val locations = SmartProxyManager.Location.values()
            val names = locations.map { it.displayName }.toTypedArray()
            android.app.AlertDialog.Builder(this)
                .setTitle("Smart VPN - Konum Seç")
                .setItems(names) { _, which ->
                    val loc = locations[which]
                    SmartProxyManager.setProxy(this, webView, loc)
                    updateVpnUi()
                    Toast.makeText(this, "${loc.displayName} seçildi, Google dahil her site açılır", Toast.LENGTH_SHORT).show()
                    webView.reload()
                }.show()
        }
    }

    private fun updateVpnUi() {
        vpnButton.text = SmartProxyManager.getStatusText()
        vpnButton.setBackgroundResource(
            if (SmartProxyManager.isVpnActive) R.drawable.bg_vpn_active else R.drawable.bg_vpn_inactive
        )
    }

    private fun setupAdBlock() {
        adBlockButton.setOnClickListener {
            AdBlocker.isEnabled = !AdBlocker.isEnabled
            Toast.makeText(this, if (AdBlocker.isEnabled) "Reklam engelleme aktif" else "Reklam engelleme kapalı", Toast.LENGTH_SHORT).show()
            webView.reload()
        }
    }

    private fun loadHome() {
        webView.loadUrl("https://www.google.com")
    }
}
