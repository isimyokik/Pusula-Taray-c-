
package com.pusula.browser

import android.graphics.Bitmap
import android.graphics.Canvas
import android.webkit.WebView
import java.util.UUID

object TabManager {
    val tabs = mutableListOf<TabModel>()
    var currentTabId: String? = null

    fun createNewTab(isPrivate: Boolean = false): TabModel {
        val tab = TabModel(id = UUID.randomUUID().toString(), isPrivate = isPrivate)
        tabs.add(tab)
        currentTabId = tab.id
        return tab
    }

    fun getCurrentTab(): TabModel? = tabs.find { it.id == currentTabId }

    fun capturePreview(webView: WebView): Bitmap? {
        return try {
            val bitmap = Bitmap.createBitmap(webView.width, webView.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            webView.draw(canvas)
            // Küçült - önizleme için
            Bitmap.createScaledBitmap(bitmap, bitmap.width / 4, bitmap.height / 4, true)
        } catch (e: Exception) { null }
    }

    fun updatePreview(tabId: String, bitmap: Bitmap?) {
        tabs.find { it.id == tabId }?.bitmap = bitmap
    }
}
