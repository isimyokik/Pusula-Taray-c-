
package com.pusula.browser

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

object AdBlocker {
    var isEnabled = true

    // Basit ama etkili liste - EasyList'ten kırpılmış
    private val adHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google", "adsystem.amazon", "facebook.com/tr",
        "analytics.google", "hotjar.com", "taboola.com", "outbrain.com",
        "popads.net", "adsterra.com", "propellerads.com"
    )

    fun shouldBlock(url: String): Boolean {
        if (!isEnabled) return false
        return adHosts.any { url.contains(it) }
    }

    fun createEmptyResponse(): WebResourceResponse {
        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream("".toByteArray()))
    }

    fun isAdRequest(request: WebResourceRequest): Boolean {
        val url = request.url.toString()
        return shouldBlock(url)
    }
}
