# Pusula Tarayıcı

Gerçek bir Android tarayıcısı: sabit adres/arama çubuğu, sekmeler, geri/ileri, ana sayfa (Google),
yer imleri, geçmiş, sayfada bul, masaüstü sitesi, indirme, ve gömülü VPN (Tor ağı, rastgele ülke).

## APK'yı GitHub ile üretme (bilgisayarsız da olur ama bilgisayarda kolay)

1. https://github.com adresinde ücretsiz hesap aç, sağ üstte **+ → New repository**.
   İsim: `pusula`, **Public** seç, **Create repository**.
2. Açılan sayfada **uploading an existing file** bağlantısına tıkla.
3. Bu zip'i bir klasöre çıkar. Klasörün **içindeki her şeyi** (app, gradle, .github, gradlew,
   build.gradle.kts, settings.gradle.kts, gradle.properties, README.md) tarayıcı penceresine sürükle.
   - `.github` klasörü gizli sayılır. Windows'ta görünür. Mac'te Cmd+Shift+. ile gizli dosyaları göster.
   - `.github` yüklenmezse: repoda **Add file → Create new file**, isme `.github/workflows/build.yml`
     yaz ve bu zip'teki `.github/workflows/build.yml` içeriğini yapıştır.
4. Aşağıda **Commit changes** düğmesine bas.
5. Üstte **Actions** sekmesine gir. "APK derle" çalışıyor olmalı (yoksa soldan "APK derle" → **Run workflow**).
6. Yeşil tik çıkınca (5-10 dk) o çalışmaya tıkla, en altta **Artifacts → pusula-apk** dosyasını indir.
   İçinden `app-debug.apk` çıkar. Telefona atıp kurabilirsin.

Kırmızı çarpı çıkarsa o adımın üstüne tıklayıp hata metnini kopyala, bana gönder; düzeltirim.

## Play Store için
Yukarıdaki APK test içindir. Play Store imzalı sürüm (AAB) ister. Testte her şey çalışınca
imzalı sürüm için workflow'a anahtar ekleme adımını birlikte yaparız.

## Bilmen gerekenler (dürüst notlar)
- VPN, uygulamaya gömülü **Tor** ağıdır. Yalnızca bu tarayıcıdaki sayfaları kapsar, telefonun
  tamamını değil. Normal VPN'den yavaştır; bazı siteler Tor çıkışlarını engeller (CAPTCHA, erişim reddi).
- VPN açıkken dosya indirme kapalıdır (gerçek adresin sızmasın diye).
- Video görüşme gibi WebRTC kullanan siteler gerçek IP'yi sızdırabilir.


### Derleme uyumluluğu düzeltmesi

- Android Gradle Plugin 8.7.3 → 8.10.1
- Gradle Wrapper 8.9 → 8.11.1
- GitHub Actions derleme adımına Java/Gradle sürüm çıktısı ve `--stacktrace` eklendi.
- CI, Java 17 kullanmaya devam eder. Bu güncelleme `Unsupported class file major version 68` hatasını çözmeyi hedefler; başarılı APK derlemesi gerçek CI çalıştırmasında doğrulanmalıdır.
