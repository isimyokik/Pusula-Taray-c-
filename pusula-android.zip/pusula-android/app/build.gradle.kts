plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pusula.browser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pusula.browser"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        // Tor her mimari için ayrı kütüphane taşır. Yalnızca telefon mimarilerini alarak APK boyutu küçültülür.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        jniLibs {
            // Tor'un libtor.so dosyası diske çıkarılarak çalışabilsin.
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")

    // Gömülü Tor (Guardian Project)
    implementation("info.guardianproject:tor-android:0.4.9.14")
    implementation("info.guardianproject:jtorctl:0.4.5.7")
}

// tor-android "compileSdk 37 ile derle" diye işaretli. Kütüphane bizim kullandığımız API'lerle uyumlu,
// bu yüzden yalnızca bu meta veri denetimi kapatılır.
tasks.configureEach {
    if (name.startsWith("check") && name.endsWith("AarMetadata")) {
        enabled = false
    }
}
