package com.pusula.browser

import android.app.Application

class App : Application() {
    /** Tor, uygulama süresince tek örnek olarak yaşar; ekran döndürmeden etkilenmez. */
    val tor: TorManager by lazy { TorManager(this) }
}
