package com.pusula.browser

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import org.torproject.jni.TorService
import java.util.concurrent.Executor
import java.util.concurrent.Executors

/**
 * Uygulamanın içine gömülü Tor'u yönetir (VPN benzeri).
 *
 * Akış: Tor servisi başlar -> bağlantı kurulana (%100) kadar beklenir -> çıkış ülkesi ayarlanır ->
 * tarayıcının tüm trafiği Tor'un SOCKS portuna yönlendirilir.
 *
 * Yalnızca bu uygulamadaki sayfalar Tor'dan geçer. Tor bağlandıktan sonra çökerse proxy yerinde
 * bırakılır; sayfalar açılmaz ama trafik sessizce doğrudan gitmez.
 */
class TorManager(context: Context) {

    enum class State { OFF, STARTING, ON, ERROR }

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val mainExecutor = Executor { main.post(it) }
    private val io = Executors.newSingleThreadExecutor()
    private val lock = Any()

    @Volatile private var state = State.OFF
    @Volatile private var country: String? = null
    @Volatile private var error: String? = null
    @Volatile private var wanted: String = "DE"
    @Volatile private var service: TorService? = null

    private var bound = false

    /** Her başlatma/kapatmada artar; eski bekleme döngüleri kendini bu sayede sonlandırır. */
    @Volatile private var generation = 0

    /** Durum her değiştiğinde ana iş parçacığında çağrılır. */
    @Volatile var onChange: (() -> Unit)? = null

    fun currentState(): State = state
    fun currentCountry(): String? = country
    fun lastError(): String? = error

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = (binder as TorService.LocalBinder).service
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            if (state == State.ON || state == State.STARTING) fail("Tor beklenmedik şekilde durdu")
        }
    }

    private fun changed() {
        main.post { onChange?.invoke() }
    }

    /** [code] iki harfli ülke kodudur (DE, NL...). Bağlantı arka planda kurulur. */
    fun connect(code: String) {
        synchronized(lock) {
            wanted = code.uppercase()
            when (state) {
                State.ON -> {
                    val gen = generation
                    io.execute { setExit(wanted, gen) }
                }
                State.STARTING -> Unit // hazır olunca istenen ülke uygulanır
                else -> start()
            }
        }
    }

    /** Kullanıcı VPN'i kapatır: Tor durur, proxy kaldırılır, sayfalar doğrudan açılır. */
    fun disconnect() {
        synchronized(lock) {
            generation++
            state = State.OFF
            error = null
            country = null
        }
        teardown(true)
        changed()
    }

    // ---- içerik ----

    private fun start() {
        var gen = 0
        var started = true
        synchronized(lock) {
            generation++
            gen = generation
            state = State.STARTING
            error = null
            country = null
            if (!bound) {
                bound = app.bindService(
                    Intent(app, TorService::class.java),
                    connection,
                    Context.BIND_AUTO_CREATE
                )
                started = bound
            }
        }
        changed()
        if (!started) {
            fail("Tor servisi başlatılamadı")
            return
        }
        val myGen = gen
        io.execute { waitUntilReady(myGen) }
    }

    private fun waitUntilReady(gen: Int) {
        val deadline = System.currentTimeMillis() + 180_000
        while (gen == generation && System.currentTimeMillis() < deadline) {
            val svc = service
            if (svc != null && bootstrapPercent(svc) >= 100) {
                val port = socksPort(svc)
                if (port > 0) {
                    if (!setExit(wanted, gen)) return
                    applyProxy(port, gen)
                    return
                }
            }
            Thread.sleep(700)
        }
        if (gen == generation) fail("Tor ağına bağlanılamadı (zaman aşımı)")
    }

    private fun bootstrapPercent(svc: TorService): Int {
        val line: String? = try {
            svc.torControlConnection?.getInfo("status/bootstrap-phase")
        } catch (e: Exception) {
            null
        }
        if (line == null) return 0
        return Regex("PROGRESS=(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    /** Tor'un SOCKS portunu kontrol bağlantısından okur (örn. "127.0.0.1:9050"). Bulunamazsa -1. */
    private fun socksPort(svc: TorService): Int {
        val line: String? = try {
            svc.torControlConnection?.getInfo("net/listeners/socks")
        } catch (e: Exception) {
            null
        }
        if (line == null) return -1
        return Regex(":(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: -1
    }

    /** Çıkış ülkesini ayarlar ve devreleri yeniler. Başarılıysa true döner. */
    private fun setExit(code: String, gen: Int): Boolean {
        if (!Regex("[A-Z]{2}").matches(code)) {
            if (gen == generation) fail("Geçersiz ülke kodu")
            return false
        }
        return try {
            val c = service?.torControlConnection ?: throw IllegalStateException("kontrol bağlantısı yok")
            c.setConf("StrictNodes", "1")
            c.setConf("ExitNodes", "{" + code.lowercase() + "}")
            c.signal("NEWNYM")
            if (gen == generation) {
                country = code
                changed()
            }
            true
        } catch (e: Exception) {
            if (gen == generation) fail("Ülke ayarlanamadı: " + (e.message ?: "bilinmeyen hata"))
            false
        }
    }

    private fun applyProxy(port: Int, gen: Int) {
        main.post {
            if (gen != generation) return@post
            try {
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
                    fail("Bu telefonun WebView sürümü proxy yönlendirmeyi desteklemiyor. Android System WebView'ı güncelleyin.")
                    return@post
                }
                val cfg = ProxyConfig.Builder()
                    .addProxyRule("socks5://127.0.0.1:$port")
                    .build()
                ProxyController.getInstance().setProxyOverride(cfg, mainExecutor) {
                    if (gen == generation) {
                        state = State.ON
                        changed()
                    }
                }
            } catch (e: Exception) {
                fail("Proxy ayarlanamadı: " + (e.message ?: "bilinmeyen hata"))
            }
        }
    }

    private fun fail(message: String) {
        synchronized(lock) {
            generation++
            state = State.ERROR
            error = message
            country = null
        }
        // Proxy bilerek kaldırılmaz: bağlantı koptuysa trafik doğrudan sızmasın.
        teardown(false)
        changed()
    }

    private fun teardown(clearProxy: Boolean) {
        synchronized(lock) {
            if (bound) {
                try {
                    app.unbindService(connection)
                } catch (e: Exception) {
                    // zaten bağlı değil
                }
                bound = false
            }
            service = null
        }
        if (clearProxy) {
            main.post {
                try {
                    if (WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
                        ProxyController.getInstance().clearProxyOverride(mainExecutor) { }
                    }
                } catch (e: Exception) {
                    // proxy zaten ayarlı değil
                }
            }
        }
    }
}
