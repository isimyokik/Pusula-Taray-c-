package com.pusula.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.text.Html
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.doAfterTextChanged
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    /** Bir sekme: kendi WebView'ı, başlığı ve adresi vardır. */
    private class BTab(val web: WebView, val bridge: PusulaBridge) {
        var title: String = "Yeni sekme"
        var url: String = ""
        var pendingUrl: String? = null
        var desktop: Boolean = false
        var mobileUa: String = ""
        var progress: Int = 100
    }

    private val tabs = ArrayList<BTab>()
    private var cur = -1
    private var shown: WebView? = null

    private lateinit var prefs: Prefs
    private lateinit var tor: TorManager
    private lateinit var loader: WebViewAssetLoader
    private val handler = Handler(Looper.getMainLooper())

    // arayüz
    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var fullscreen: FrameLayout
    private lateinit var urlField: EditText
    private lateinit var progress: ProgressBar
    private lateinit var vpnChip: TextView
    private lateinit var backBtn: ImageButton
    private lateinit var fwdBtn: ImageButton
    private lateinit var tabCount: TextView
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView
    private lateinit var gate: LinearLayout
    private lateinit var gateText: TextView
    private lateinit var gateSpinner: ProgressBar
    private lateinit var gateRetry: Button

    // renkler
    private var dark = false
    private var cBg = 0
    private var cSurface = 0
    private var cField = 0
    private var cText = 0
    private var cSub = 0
    private var cIcon = 0
    private val cAccent = 0xFF2F6BFF.toInt()

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var gateOpen = false
    private var startUrl: String? = null

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            fileCb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
            )
            fileCb = null
        }

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        tor = (application as App).tor
        loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        cBg = if (dark) 0xFF0F1115.toInt() else 0xFFF4F5F7.toInt()
        cSurface = if (dark) 0xFF1A1D23.toInt() else 0xFFFFFFFF.toInt()
        cField = if (dark) 0xFF2A2E36.toInt() else 0xFFEDEFF3.toInt()
        cText = if (dark) 0xFFE8EAED.toInt() else 0xFF1B1F24.toInt()
        cSub = if (dark) 0xFF9AA0A6.toInt() else 0xFF6B7280.toInt()
        cIcon = if (dark) 0xFFD5D8DD.toInt() else 0xFF3C4350.toInt()

        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()
        val bars = WindowInsetsControllerCompat(window, window.decorView)
        bars.isAppearanceLightStatusBars = !dark
        bars.isAppearanceLightNavigationBars = !dark

        tor.onChange = { onVpnChanged() }
        startUrl = intent?.dataString
        updateChip()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })

        if (prefs.autoVpn && tor.currentState() != TorManager.State.ON) {
            showGate()
            if (tor.currentState() == TorManager.State.OFF || tor.currentState() == TorManager.State.ERROR) {
                tor.connect(randomCountry())
            }
        } else {
            startBrowsing()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val u = intent.dataString ?: return
        if (gateOpen) {
            startUrl = u
        } else {
            openTab(u)
        }
    }

    override fun onPause() {
        super.onPause()
        saveTabs()
        CookieManager.getInstance().flush()
        shown?.onPause()
    }

    override fun onResume() {
        super.onResume()
        shown?.onResume()
    }

    override fun onDestroy() {
        tor.onChange = null
        for (t in tabs) {
            try {
                t.web.destroy()
            } catch (e: Exception) {
                // yok say
            }
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ arayüz kurulumu

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun shape(color: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) g.setStroke(dp(strokeDp), stroke)
        return g
    }

    private fun ripple(content: Drawable?): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(0x33888888), content, ColorDrawable(Color.WHITE))

    private fun iconBtn(res: Int, desc: String, onClick: (View) -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(cIcon)
        b.background = ripple(null)
        b.contentDescription = desc
        b.scaleType = ImageView.ScaleType.CENTER
        b.setOnClickListener { v -> onClick(v) }
        return b
    }

    private fun textBtn(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 16f
        t.setTextColor(cIcon)
        t.gravity = Gravity.CENTER
        t.background = ripple(null)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildUi() {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(cSurface)
        root.isFocusable = true
        root.isFocusableInTouchMode = true

        // --- üst çubuk: VPN, adres/arama, yenile
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(6), dp(4), dp(6))

        vpnChip = TextView(this)
        vpnChip.textSize = 12f
        vpnChip.setTypeface(null, Typeface.BOLD)
        vpnChip.gravity = Gravity.CENTER
        vpnChip.setPadding(dp(10), 0, dp(10), 0)
        vpnChip.setOnClickListener { showVpnDialog() }
        top.addView(vpnChip, LinearLayout.LayoutParams(wrap, dp(36)))

        urlField = EditText(this)
        urlField.hint = "Ara veya adres yaz"
        urlField.setHintTextColor(cSub)
        urlField.setTextColor(cText)
        urlField.textSize = 15f
        urlField.isSingleLine = true
        urlField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        urlField.imeOptions = EditorInfo.IME_ACTION_GO
        urlField.setSelectAllOnFocus(true)
        urlField.background = shape(cField, 20)
        urlField.setPadding(dp(14), 0, dp(14), 0)
        urlField.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)
            ) {
                submitUrl()
                true
            } else {
                false
            }
        }
        urlField.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) syncUrlText()
        }
        val ulp = LinearLayout.LayoutParams(0, dp(40), 1f)
        ulp.leftMargin = dp(8)
        ulp.rightMargin = dp(2)
        top.addView(urlField, ulp)

        top.addView(
            iconBtn(R.drawable.ic_reload, "Yenile") { reloadCurrent() },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        root.addView(top, LinearLayout.LayoutParams(match, wrap))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.progressTintList = ColorStateList.valueOf(cAccent)
        progress.visibility = View.INVISIBLE
        root.addView(progress, LinearLayout.LayoutParams(match, dp(3)))

        // --- sayfa alanı
        content = FrameLayout(this)
        content.setBackgroundColor(cBg)
        root.addView(content, LinearLayout.LayoutParams(match, 0, 1f))

        buildGate()

        // --- sayfada bul çubuğu
        findBar = LinearLayout(this)
        findBar.orientation = LinearLayout.HORIZONTAL
        findBar.gravity = Gravity.CENTER_VERTICAL
        findBar.setBackgroundColor(cSurface)
        findBar.setPadding(dp(8), dp(4), dp(4), dp(4))
        findBar.visibility = View.GONE
        findInput = EditText(this)
        findInput.hint = "Sayfada bul"
        findInput.setHintTextColor(cSub)
        findInput.setTextColor(cText)
        findInput.textSize = 15f
        findInput.isSingleLine = true
        findInput.background = shape(cField, 18)
        findInput.setPadding(dp(12), 0, dp(12), 0)
        findInput.doAfterTextChanged { text ->
            val t = text?.toString() ?: ""
            val web = currentWeb()
            if (web != null) {
                if (t.isEmpty()) {
                    web.clearMatches()
                    findCount.text = ""
                } else {
                    web.findAllAsync(t)
                }
            }
        }
        findBar.addView(findInput, LinearLayout.LayoutParams(0, dp(36), 1f))
        findCount = TextView(this)
        findCount.setTextColor(cSub)
        findCount.textSize = 13f
        findCount.setPadding(dp(8), 0, dp(8), 0)
        findBar.addView(findCount, LinearLayout.LayoutParams(wrap, wrap))
        findBar.addView(textBtn("▲") { currentWeb()?.findNext(false) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        findBar.addView(textBtn("▼") { currentWeb()?.findNext(true) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        findBar.addView(textBtn("✕") { closeFind() }, LinearLayout.LayoutParams(dp(40), dp(40)))
        root.addView(findBar, LinearLayout.LayoutParams(match, wrap))

        // --- alt çubuk: geri, ileri, ana sayfa, yeni sekme, sekmeler, menü
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setBackgroundColor(cSurface)

        backBtn = iconBtn(R.drawable.ic_back, "Geri") { goBack() }
        fwdBtn = iconBtn(R.drawable.ic_forward, "İleri") { goForward() }
        val homeBtn = iconBtn(R.drawable.ic_home, "Ana sayfa") { goHome() }
        val addBtn = iconBtn(R.drawable.ic_add, "Yeni sekme") { openTab(null) }
        val menuBtn = iconBtn(R.drawable.ic_menu, "Menü") { v -> showMenu(v) }

        val tabsWrap = FrameLayout(this)
        tabsWrap.background = ripple(null)
        tabsWrap.contentDescription = "Sekmeler"
        tabsWrap.setOnClickListener { showTabs() }
        tabCount = TextView(this)
        tabCount.gravity = Gravity.CENTER
        tabCount.textSize = 12f
        tabCount.setTypeface(null, Typeface.BOLD)
        tabCount.setTextColor(cIcon)
        tabCount.background = shape(0, 5, cIcon, 2)
        tabsWrap.addView(tabCount, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))

        for (v in listOf<View>(backBtn, fwdBtn, homeBtn, addBtn, tabsWrap, menuBtn)) {
            bottom.addView(v, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        root.addView(bottom, LinearLayout.LayoutParams(match, wrap))

        // --- tam ekran video katmanı
        fullscreen = FrameLayout(this)
        fullscreen.setBackgroundColor(Color.BLACK)
        fullscreen.visibility = View.GONE

        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(match, match))
        frame.addView(fullscreen, FrameLayout.LayoutParams(match, match))
        setContentView(frame)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        root.requestFocus()
        updateTabCount()
    }

    private fun buildGate() {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        gate = LinearLayout(this)
        gate.orientation = LinearLayout.VERTICAL
        gate.gravity = Gravity.CENTER
        gate.setBackgroundColor(cBg)
        gate.setPadding(dp(32), dp(32), dp(32), dp(32))
        gate.visibility = View.GONE
        gate.isClickable = true

        val title = TextView(this)
        title.text = "Pusula"
        title.textSize = 30f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(cText)
        title.gravity = Gravity.CENTER
        gate.addView(title, LinearLayout.LayoutParams(match, wrap))

        gateText = TextView(this)
        gateText.textSize = 15f
        gateText.setTextColor(cSub)
        gateText.gravity = Gravity.CENTER
        gateText.setPadding(0, dp(12), 0, dp(16))
        gate.addView(gateText, LinearLayout.LayoutParams(match, wrap))

        gateSpinner = ProgressBar(this)
        gate.addView(gateSpinner, LinearLayout.LayoutParams(wrap, wrap))

        gateRetry = Button(this)
        gateRetry.text = "Tekrar dene"
        gateRetry.visibility = View.GONE
        gateRetry.setOnClickListener {
            showGate()
            tor.connect(randomCountry())
        }
        gate.addView(gateRetry, LinearLayout.LayoutParams(wrap, wrap))

        val skip = Button(this)
        skip.text = "VPN olmadan devam et"
        skip.setOnClickListener {
            if (tor.currentState() != TorManager.State.OFF) tor.disconnect()
            startBrowsing()
        }
        gate.addView(skip, LinearLayout.LayoutParams(wrap, wrap))

        content.addView(gate, FrameLayout.LayoutParams(match, match))
    }

    // ------------------------------------------------------------------ açılış kapısı (VPN bağlanana kadar bekler)

    private fun showGate() {
        gateOpen = true
        gate.visibility = View.VISIBLE
        gate.bringToFront()
        gateText.text = "VPN bağlanıyor…\nİlk bağlantı 10-60 saniye sürebilir."
        gateSpinner.visibility = View.VISIBLE
        gateRetry.visibility = View.GONE
    }

    private fun startBrowsing() {
        gateOpen = false
        gate.visibility = View.GONE
        if (tabs.isEmpty()) {
            val saved = prefs.savedTabs()
            if (saved.isEmpty()) {
                openTab(null)
            } else {
                val want = prefs.savedCurrent()
                for (u in saved.take(12)) {
                    val t = createTab()
                    if (u.startsWith("http")) {
                        t.pendingUrl = u
                        t.url = u
                        t.title = shownUrl(u)
                    } else {
                        t.pendingUrl = NEWTAB_URL
                    }
                }
                switchTo(if (want in tabs.indices) want else 0)
            }
        }
        val s = startUrl
        startUrl = null
        if (s != null) openTab(s)
    }

    private fun onVpnChanged() {
        updateChip()
        if (gateOpen) {
            when (tor.currentState()) {
                TorManager.State.ON -> startBrowsing()
                TorManager.State.ERROR -> {
                    gateText.text = (tor.lastError() ?: "VPN bağlanamadı") +
                        "\n\nTekrar deneyebilir ya da VPN olmadan devam edebilirsiniz."
                    gateSpinner.visibility = View.GONE
                    gateRetry.visibility = View.VISIBLE
                }
                else -> Unit
            }
        }
    }

    private fun updateChip() {
        val st = tor.currentState()
        val label: String
        val bg: Int
        val fg: Int
        when (st) {
            TorManager.State.ON -> {
                label = "VPN · " + (tor.currentCountry() ?: "")
                bg = 0xFF1F9D55.toInt()
                fg = Color.WHITE
            }
            TorManager.State.STARTING -> {
                label = "VPN…"
                bg = 0xFFE8A200.toInt()
                fg = Color.WHITE
            }
            TorManager.State.ERROR -> {
                label = "VPN hata"
                bg = 0xFFD64545.toInt()
                fg = Color.WHITE
            }
            else -> {
                label = "VPN kapalı"
                bg = cField
                fg = cSub
            }
        }
        vpnChip.text = label
        vpnChip.setTextColor(fg)
        vpnChip.background = shape(bg, 18)
    }

    // ------------------------------------------------------------------ sekmeler

    private fun currentWeb(): WebView? = if (cur in tabs.indices) tabs[cur].web else null

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun createTab(): BTab {
        val web = WebView(this)
        val bridge = PusulaBridge(prefs)
        val tab = BTab(web, bridge)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setGeolocationEnabled(false)
        s.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        // "wv" işareti kalkınca Google girişi ve bazı siteler normal tarayıcı gibi davranır.
        val ua = s.userAgentString
            .replace("; wv", "")
            .replace(Regex("Version/\\d+\\.\\d+ "), "")
        s.userAgentString = ua
        tab.mobileUa = ua
        web.addJavascriptInterface(bridge, "Pusula")
        web.setFindListener { active, total, _ ->
            if (tabs.getOrNull(cur) === tab) {
                findCount.text = if (total == 0) "0" else "${active + 1}/$total"
            }
        }
        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(url, userAgent, contentDisposition, mimeType)
        }
        web.webViewClient = makeClient(tab)
        web.webChromeClient = makeChrome(tab)
        tabs.add(tab)
        updateTabCount()
        return tab
    }

    /** Yeni sekme açar. [url] null ise Pusula başlangıç sayfası açılır. */
    private fun openTab(url: String?, load: Boolean = true): BTab? {
        if (tabs.size >= MAX_TABS) {
            toast("En fazla $MAX_TABS sekme açılabilir")
            return null
        }
        val t = createTab()
        switchTo(tabs.size - 1)
        if (load) t.web.loadUrl(url ?: NEWTAB_URL)
        return t
    }

    private fun switchTo(i: Int) {
        if (i !in tabs.indices) return
        shown?.let {
            content.removeView(it)
            it.onPause()
        }
        cur = i
        val t = tabs[i]
        shown = t.web
        content.addView(t.web, 0, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        t.web.onResume()
        val p = t.pendingUrl
        if (p != null) {
            t.pendingUrl = null
            t.web.loadUrl(p)
        }
        closeFind()
        syncUi()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val t = tabs[index]
        val wasCurrent = index == cur
        if (wasCurrent) {
            content.removeView(t.web)
            shown = null
        }
        t.web.stopLoading()
        t.web.destroy()
        tabs.removeAt(index)
        if (tabs.isEmpty()) {
            cur = -1
            openTab(null)
            return
        }
        if (wasCurrent) {
            switchTo(minOf(index, tabs.size - 1))
        } else if (index < cur) {
            cur--
        }
        updateTabCount()
    }

    private fun updateTabCount() {
        tabCount.text = tabs.size.toString()
    }

    private fun saveTabs() {
        if (tabs.isEmpty()) return
        val urls = ArrayList<String>()
        for (t in tabs) {
            val u = t.pendingUrl ?: t.url
            urls.add(if (u.startsWith("http")) u else NEWTAB_URL)
        }
        prefs.saveTabs(urls, if (cur >= 0) cur else 0)
    }

    // ------------------------------------------------------------------ gezinti

    private fun shownUrl(u: String): String =
        if (u.isEmpty() || u.startsWith(ASSET_PREFIX)) ""
        else u.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

    private fun syncUrlText() {
        val t = tabs.getOrNull(cur)
        urlField.setText(if (t == null) "" else shownUrl(t.pendingUrl ?: t.url))
    }

    private fun syncUi() {
        val t = tabs.getOrNull(cur) ?: return
        if (!urlField.hasFocus()) syncUrlText()
        setLoadProgress(t.progress)
        refreshNav()
        updateTabCount()
    }

    private fun setLoadProgress(p: Int) {
        progress.progress = p
        progress.visibility = if (p in 1..99) View.VISIBLE else View.INVISIBLE
    }

    private fun refreshNav() {
        val web = currentWeb()
        backBtn.alpha = if (web != null && (web.canGoBack() || tabs.size > 1)) 1f else 0.35f
        fwdBtn.alpha = if (web != null && web.canGoForward()) 1f else 0.35f
    }

    private fun loadInCurrent(url: String) {
        val t = tabs.getOrNull(cur) ?: return
        t.pendingUrl = null
        t.web.loadUrl(url)
    }

    private fun submitUrl() {
        val text = urlField.text.toString()
        loadInCurrent(resolveInput(text, Engines.get(prefs.engine)))
        hideKeyboard()
        urlField.clearFocus()
        root.requestFocus()
    }

    private fun goBack() {
        val web = currentWeb() ?: return
        if (web.canGoBack()) web.goBack() else if (tabs.size > 1) closeTab(cur)
    }

    private fun goForward() {
        val web = currentWeb() ?: return
        if (web.canGoForward()) web.goForward()
    }

    private fun goHome() {
        loadInCurrent(Engines.get(prefs.engine).home)
    }

    private fun reloadCurrent() {
        val t = tabs.getOrNull(cur) ?: return
        if (t.progress in 1..99) t.web.stopLoading() else t.web.reload()
    }

    private fun handleBack() {
        val web = currentWeb()
        when {
            customView != null -> hideCustom()
            findBar.visibility == View.VISIBLE -> closeFind()
            urlField.hasFocus() -> {
                hideKeyboard()
                urlField.clearFocus()
                root.requestFocus()
            }
            gateOpen -> finish()
            web != null && web.canGoBack() -> web.goBack()
            tabs.size > 1 -> closeTab(cur)
            else -> finish()
        }
    }

    // ------------------------------------------------------------------ WebView istemcileri

    private fun makeClient(tab: BTab): WebViewClient = object : WebViewClient() {

        override fun shouldInterceptRequest(
            view: WebView?,
            request: WebResourceRequest?
        ): WebResourceResponse? = request?.url?.let { loader.shouldInterceptRequest(it) }

        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val u = request?.url ?: return false
            val scheme = u.scheme ?: return false
            return when (scheme) {
                "http", "https", "about", "blob", "data" -> false
                "file", "content", "javascript" -> true
                else -> openExternal(u.toString())
            }
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            val u = url ?: ""
            tab.bridge.trusted = u.startsWith(ASSET_PREFIX)
            tab.url = u
            tab.progress = 5
            if (tabs.getOrNull(cur) === tab) syncUi()
        }

        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
            if (url != null && !url.startsWith("data:")) tab.url = url
            if (tabs.getOrNull(cur) === tab) syncUi()
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            tab.progress = 100
            val u = url ?: return
            if (u.startsWith("http")) {
                val title = view?.title
                prefs.addHistory(if (title.isNullOrBlank()) u else title, u)
            }
            if (tabs.getOrNull(cur) === tab) syncUi()
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?
        ) {
            if (view == null || request == null || error == null) return
            if (!request.isForMainFrame) return
            val desc = error.description?.toString() ?: ""
            if (desc.contains("ERR_ABORTED")) return
            val failing = request.url.toString()
            view.loadDataWithBaseURL(failing, errorHtml(failing, desc), "text/html", "utf-8", failing)
        }
    }

    private fun makeChrome(tab: BTab): WebChromeClient = object : WebChromeClient() {

        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            tab.progress = newProgress
            if (tabs.getOrNull(cur) === tab) setLoadProgress(newProgress)
        }

        override fun onReceivedTitle(view: WebView?, title: String?) {
            if (!title.isNullOrBlank()) tab.title = title
        }

        override fun onCreateWindow(
            view: WebView?,
            isDialog: Boolean,
            isUserGesture: Boolean,
            resultMsg: Message?
        ): Boolean {
            if (!isUserGesture || resultMsg == null) return false
            val nt = openTab(null, false) ?: return false
            val transport = resultMsg.obj as WebView.WebViewTransport
            transport.webView = nt.web
            resultMsg.sendToTarget()
            return true
        }

        override fun onCloseWindow(window: WebView?) {
            handler.post {
                val i = tabs.indexOfFirst { it.web === window }
                if (i >= 0) closeTab(i)
            }
        }

        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            fileCb?.onReceiveValue(null)
            fileCb = filePathCallback
            return try {
                fileLauncher.launch(fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).setType("*/*"))
                true
            } catch (e: Exception) {
                fileCb?.onReceiveValue(null)
                fileCb = null
                false
            }
        }

        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
            if (view == null || customView != null) {
                callback?.onCustomViewHidden()
                return
            }
            customView = view
            customCb = callback
            fullscreen.addView(view, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            fullscreen.visibility = View.VISIBLE
            setBars(false)
        }

        override fun onHideCustomView() {
            hideCustom()
        }

        override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                .setOnCancelListener { result?.confirm() }
                .show()
            return true
        }

        override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                .setOnCancelListener { result?.cancel() }
                .show()
            return true
        }

        override fun onJsPrompt(
            view: WebView?,
            url: String?,
            message: String?,
            defaultValue: String?,
            result: JsPromptResult?
        ): Boolean {
            val input = EditText(this@MainActivity)
            input.setText(defaultValue ?: "")
            AlertDialog.Builder(this@MainActivity)
                .setMessage(message)
                .setView(input)
                .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm(input.text.toString()) }
                .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                .setOnCancelListener { result?.cancel() }
                .show()
            return true
        }
    }

    private fun hideCustom() {
        val v = customView ?: return
        fullscreen.removeView(v)
        fullscreen.visibility = View.GONE
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        setBars(true)
    }

    private fun setBars(show: Boolean) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (show) {
            c.show(WindowInsetsCompat.Type.systemBars())
        } else {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun openExternal(url: String): Boolean {
        try {
            val i = if (url.startsWith("intent:")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            startActivity(i)
        } catch (e: Exception) {
            toast("Bu bağlantıyı açacak uygulama bulunamadı")
        }
        return true
    }

    private fun errorHtml(url: String, desc: String): String {
        val bg = if (dark) "#0f1115" else "#f4f5f7"
        val fg = if (dark) "#e8eaed" else "#1b1f24"
        val note = if (tor.currentState() != TorManager.State.OFF) {
            "<p>VPN açık olduğu için sayfalar yavaş açılabilir ya da bazı siteler Tor'u engeller. VPN ülkesini değiştirmeyi deneyin.</p>"
        } else {
            ""
        }
        val js = Html.escapeHtml("location.href=" + JSONObject.quote(url))
        return "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<title>Sayfa açılamadı</title><style>" +
            "body{font-family:sans-serif;margin:0;padding:32px 24px;background:" + bg + ";color:" + fg + "}" +
            "h1{font-size:22px}p{opacity:.75;line-height:1.5;word-break:break-word}" +
            "button{margin-top:12px;padding:12px 20px;border:0;border-radius:22px;background:#2f6bff;color:#fff;font-size:16px}" +
            "</style></head><body><h1>Sayfa açılamadı</h1><p>" + Html.escapeHtml(url) + "</p><p>" +
            Html.escapeHtml(desc) + "</p>" + note +
            "<button onclick=\"" + js + "\">Tekrar dene</button></body></html>"
    }

    // ------------------------------------------------------------------ indirme

    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        if (!url.startsWith("http")) {
            toast("Bu indirme türü desteklenmiyor")
            return
        }
        if (tor.currentState() != TorManager.State.OFF) {
            toast("VPN açıkken indirme yapılamaz (gerçek adresiniz sızabilir). Önce VPN'i kapatın.")
            return
        }
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
            if (mime != null) req.setMimeType(mime)
            val cookie = CookieManager.getInstance().getCookie(url)
            if (cookie != null) req.addRequestHeader("Cookie", cookie)
            if (ua != null) req.addRequestHeader("User-Agent", ua)
            req.setTitle(name)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            if (Build.VERSION.SDK_INT >= 29) {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            } else {
                req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
            }
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("İndirme başladı: $name")
        } catch (e: Exception) {
            toast("İndirme başlatılamadı")
        }
    }

    // ------------------------------------------------------------------ menü ve pencereler

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
    }

    private fun showMenu(anchor: View) {
        val t = tabs.getOrNull(cur) ?: return
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        val marked = t.url.startsWith("http") && prefs.isBookmarked(t.url)
        m.add(0, 1, 0, "Yeni sekme")
        m.add(0, 2, 1, if (marked) "Yer imini kaldır" else "Yer imi ekle")
        m.add(0, 3, 2, "Yer imleri")
        m.add(0, 4, 3, "Geçmiş")
        m.add(0, 5, 4, "Sayfada bul")
        val desk = m.add(0, 6, 5, "Masaüstü sitesi")
        desk.isCheckable = true
        desk.isChecked = t.desktop
        m.add(0, 7, 6, "Paylaş")
        m.add(0, 8, 7, "VPN")
        m.add(0, 9, 8, "Ayarlar")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> openTab(null)
                2 -> toggleBookmark()
                3 -> showBookmarks()
                4 -> showHistory()
                5 -> openFind()
                6 -> toggleDesktop()
                7 -> shareCurrent()
                8 -> showVpnDialog()
                9 -> showSettings()
            }
            true
        }
        pm.show()
    }

    private fun toggleBookmark() {
        val t = tabs.getOrNull(cur) ?: return
        if (!t.url.startsWith("http")) {
            toast("Bu sayfa yer imi olarak eklenemez")
            return
        }
        val added = prefs.toggleBookmark(if (t.title.isBlank()) t.url else t.title, t.url)
        toast(if (added) "Yer imi eklendi" else "Yer imi kaldırıldı")
    }

    private fun showBookmarks() {
        showEntries("Yer imleri", prefs.bookmarks(), { prefs.removeBookmark(it.url) }, null)
    }

    private fun showHistory() {
        showEntries("Geçmiş", prefs.history(), { prefs.removeHistory(it.url) },
            Pair<String, () -> Unit>("Temizle", { prefs.clearHistory() }))
    }

    private fun showEntries(
        title: String,
        list: List<Prefs.Entry>,
        onDelete: (Prefs.Entry) -> Unit,
        neutral: Pair<String, () -> Unit>?
    ) {
        if (list.isEmpty()) {
            toast("Liste boş")
            return
        }
        val labels = list.map { (if (it.title.isBlank()) it.url else it.title) + "\n" + shownUrl(it.url) }
        val lv = ListView(this)
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        val b = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(lv)
            .setNegativeButton("Kapat", null)
        if (neutral != null) {
            b.setNeutralButton(neutral.first) { _, _ -> neutral.second() }
        }
        val d = b.create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            d.dismiss()
            loadInCurrent(list[pos].url)
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this)
                .setMessage("Listeden silinsin mi?")
                .setPositiveButton("Sil") { _, _ ->
                    onDelete(list[pos])
                    d.dismiss()
                }
                .setNegativeButton("Vazgeç", null)
                .show()
            true
        }
        d.show()
        toast("Silmek için basılı tutun")
    }

    private fun openFind() {
        findBar.visibility = View.VISIBLE
        findInput.setText("")
        findCount.text = ""
        findInput.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(findInput, 0)
    }

    private fun closeFind() {
        if (findBar.visibility != View.VISIBLE) return
        findBar.visibility = View.GONE
        currentWeb()?.clearMatches()
        hideKeyboard()
        root.requestFocus()
    }

    private fun toggleDesktop() {
        val t = tabs.getOrNull(cur) ?: return
        t.desktop = !t.desktop
        val s = t.web.settings
        if (t.desktop) {
            val chrome = Regex("Chrome/[\\d.]+").find(t.mobileUa)?.value ?: "Chrome/120.0.0.0"
            s.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) $chrome Safari/537.36"
        } else {
            s.userAgentString = t.mobileUa
        }
        t.web.reload()
    }

    private fun shareCurrent() {
        val t = tabs.getOrNull(cur) ?: return
        if (!t.url.startsWith("http")) {
            toast("Paylaşılacak bir sayfa yok")
            return
        }
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, t.url)
        startActivity(Intent.createChooser(i, "Paylaş"))
    }

    private fun showTabs() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        val scroll = ScrollView(this)
        scroll.addView(box)
        val d = AlertDialog.Builder(this)
            .setTitle("Sekmeler")
            .setView(scroll)
            .setPositiveButton("Yeni sekme") { _, _ -> openTab(null) }
            .setNeutralButton("Hepsini kapat") { _, _ -> closeAllTabs() }
            .setNegativeButton("Kapat", null)
            .create()
        fillTabs(box, d)
        d.show()
    }

    private fun fillTabs(box: LinearLayout, d: AlertDialog) {
        box.removeAllViews()
        for (i in tabs.indices) {
            val t = tabs[i]
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = shape(if (i == cur) cField else 0, 10)
            row.setPadding(dp(12), dp(6), dp(4), dp(6))
            row.setOnClickListener {
                d.dismiss()
                switchTo(i)
            }
            val label = TextView(this)
            val url = t.pendingUrl ?: t.url
            val name = if (t.title.isBlank()) shownUrl(url) else t.title
            label.text = (if (name.isEmpty()) "Yeni sekme" else name) + "\n" + shownUrl(url)
            label.textSize = 14f
            label.maxLines = 2
            label.setTextColor(cText)
            if (i == cur) label.setTypeface(null, Typeface.BOLD)
            row.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(textBtn("✕") {
                closeTab(i)
                fillTabs(box, d)
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(4)
            box.addView(row, lp)
        }
    }

    private fun closeAllTabs() {
        while (tabs.size > 1) closeTab(tabs.size - 1)
        val t = tabs.getOrNull(0) ?: return
        t.web.clearHistory()
        loadInCurrent(NEWTAB_URL)
    }

    // ------------------------------------------------------------------ VPN penceresi

    private fun randomCountry(): String = RANDOM_POOL.random()

    private fun countryName(code: String?): String =
        COUNTRIES.firstOrNull { it.first == code }?.second ?: (code ?: "")

    private fun showVpnDialog() {
        val st = tor.currentState()
        val title = when (st) {
            TorManager.State.ON -> "VPN bağlı: " + countryName(tor.currentCountry())
            TorManager.State.STARTING -> "VPN bağlanıyor…"
            TorManager.State.ERROR -> "VPN hatası: " + (tor.lastError() ?: "")
            else -> "VPN kapalı"
        }
        val items = ArrayList<String>()
        items.add("Rastgele ülkeye bağlan")
        for (c in COUNTRIES) items.add(c.second + " (" + c.first + ")")
        if (st != TorManager.State.OFF) items.add("VPN'i kapat")
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, which ->
                when {
                    which == 0 -> tor.connect(randomCountry())
                    which <= COUNTRIES.size -> tor.connect(COUNTRIES[which - 1].first)
                    else -> confirmVpnOff()
                }
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun confirmVpnOff() {
        AlertDialog.Builder(this)
            .setMessage("VPN kapatılsın mı? Sayfalar doğrudan, kendi bağlantınızla açılır.")
            .setPositiveButton("Kapat") { _, _ -> tor.disconnect() }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    // ------------------------------------------------------------------ ayarlar

    private fun showSettings() {
        val eng = Engines.get(prefs.engine)
        val items = arrayOf(
            "Arama motoru: " + eng.name,
            "Açılışta otomatik VPN: " + (if (prefs.autoVpn) "açık" else "kapalı"),
            "Geçmişi temizle",
            "Çerezleri ve önbelleği temizle",
            "Hakkında"
        )
        AlertDialog.Builder(this)
            .setTitle("Ayarlar")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> chooseEngine()
                    1 -> {
                        prefs.autoVpn = !prefs.autoVpn
                        toast("Açılışta otomatik VPN: " + (if (prefs.autoVpn) "açık" else "kapalı"))
                    }
                    2 -> {
                        prefs.clearHistory()
                        toast("Geçmiş temizlendi")
                    }
                    3 -> clearBrowsingData()
                    4 -> AlertDialog.Builder(this)
                        .setTitle("Pusula")
                        .setMessage("Gizlilik odaklı tarayıcı. VPN, uygulamanın içine gömülü Tor ağı ile çalışır; yalnızca bu tarayıcıdaki sayfaları kapsar. Tor yavaştır ve bazı siteler Tor çıkışlarını engeller.")
                        .setPositiveButton(android.R.string.ok, null)
                        .show()
                }
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun chooseEngine() {
        val names = Engines.all.map { it.name }.toTypedArray()
        val sel = Engines.all.indexOfFirst { it.id == prefs.engine }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Arama motoru")
            .setSingleChoiceItems(names, sel) { dlg, which ->
                prefs.engine = Engines.all[which].id
                dlg.dismiss()
            }
            .show()
    }

    private fun clearBrowsingData() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        for (t in tabs) t.web.clearCache(true)
        toast("Çerezler ve önbellek temizlendi")
    }

    private companion object {
        const val ASSET_PREFIX = "https://appassets.androidplatform.net/"
        const val NEWTAB_URL = "https://appassets.androidplatform.net/assets/newtab.html"
        const val MAX_TABS = 20

        val RANDOM_POOL = listOf("DE", "NL", "FR", "SE", "CH", "GB")
        val COUNTRIES = listOf(
            "DE" to "Almanya",
            "NL" to "Hollanda",
            "FR" to "Fransa",
            "SE" to "İsveç",
            "CH" to "İsviçre",
            "GB" to "Birleşik Krallık",
            "AT" to "Avusturya",
            "NO" to "Norveç",
            "FI" to "Finlandiya",
            "CA" to "Kanada",
            "US" to "ABD",
            "RO" to "Romanya",
            "PL" to "Polonya",
            "ES" to "İspanya",
            "IT" to "İtalya",
            "JP" to "Japonya"
        )
    }
}
