package com.pusula.browser

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Arama motorları. */
object Engines {
    class E(val id: String, val name: String, val search: String, val home: String)

    val all: List<E> = listOf(
        E("google", "Google", "https://www.google.com/search?q=%s", "https://www.google.com/"),
        E("ddg", "DuckDuckGo", "https://duckduckgo.com/?q=%s", "https://duckduckgo.com/"),
        E("bing", "Bing", "https://www.bing.com/search?q=%s", "https://www.bing.com/"),
        E("yandex", "Yandex", "https://yandex.com.tr/search/?text=%s", "https://yandex.com.tr/")
    )

    fun get(id: String): E = all.firstOrNull { it.id == id } ?: all[0]
}

private val HOST_LIKE = Regex(
    "^([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,}([:/?#].*)?$|^(\\d{1,3}\\.){3}\\d{1,3}([:/?#].*)?$|^localhost([:/?#].*)?$"
)

/** Adres çubuğuna yazılanı adrese ya da arama adresine çevirir. */
fun resolveInput(raw: String, engine: Engines.E): String {
    val t = raw.trim()
    if (t.isEmpty()) return engine.home
    if (t.startsWith("http://", ignoreCase = true) || t.startsWith("https://", ignoreCase = true)) return t
    if (!t.contains(' ') && HOST_LIKE.matches(t)) return "https://" + t
    return engine.search.replace("%s", Uri.encode(t))
}

/** Ayarlar, yer imleri, geçmiş ve açık sekmeler. Hepsi yalnızca telefonda saklanır. */
class Prefs(context: Context) {

    class Entry(val title: String, val url: String)

    private val sp = context.getSharedPreferences("pusula", Context.MODE_PRIVATE)

    var engine: String
        get() = sp.getString("engine", "google") ?: "google"
        set(v) { sp.edit().putString("engine", v).apply() }

    var autoVpn: Boolean
        get() = sp.getBoolean("autoVpn", false)
        set(v) { sp.edit().putBoolean("autoVpn", v).apply() }

    private fun readList(key: String): MutableList<Entry> {
        val out = ArrayList<Entry>()
        try {
            val arr = JSONArray(sp.getString(key, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.optString("u")))
            }
        } catch (e: Exception) {
            // bozuk veri: boş liste
        }
        return out
    }

    private fun writeList(key: String, list: List<Entry>) {
        val arr = JSONArray()
        for (e in list) arr.put(JSONObject().put("t", e.title).put("u", e.url))
        sp.edit().putString(key, arr.toString()).apply()
    }

    // ---- yer imleri ----

    fun bookmarks(): List<Entry> = readList("bookmarks")

    fun isBookmarked(url: String): Boolean = bookmarks().any { it.url == url }

    /** Yer imi yoksa ekler, varsa kaldırır. Eklenmişse true döner. */
    fun toggleBookmark(title: String, url: String): Boolean {
        val list = readList("bookmarks")
        val had = list.removeAll { it.url == url }
        if (!had) list.add(0, Entry(title, url))
        writeList("bookmarks", list)
        return !had
    }

    fun removeBookmark(url: String) {
        val list = readList("bookmarks")
        list.removeAll { it.url == url }
        writeList("bookmarks", list)
    }

    // ---- geçmiş ----

    fun history(): List<Entry> = readList("history")

    fun addHistory(title: String, url: String) {
        val list = readList("history")
        if (list.isNotEmpty() && list[0].url == url) return
        list.add(0, Entry(title, url))
        while (list.size > 300) list.removeAt(list.size - 1)
        writeList("history", list)
    }

    fun removeHistory(url: String) {
        val list = readList("history")
        list.removeAll { it.url == url }
        writeList("history", list)
    }

    fun clearHistory() {
        sp.edit().putString("history", "[]").apply()
    }

    // ---- açık sekmeler ----

    fun saveTabs(urls: List<String>, current: Int) {
        val arr = JSONArray()
        for (u in urls) arr.put(u)
        sp.edit().putString("tabs", arr.toString()).putInt("tabCur", current).apply()
    }

    fun savedTabs(): List<String> {
        val out = ArrayList<String>()
        try {
            val arr = JSONArray(sp.getString("tabs", "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (e: Exception) {
            // bozuk veri
        }
        return out
    }

    fun savedCurrent(): Int = sp.getInt("tabCur", 0)
}
