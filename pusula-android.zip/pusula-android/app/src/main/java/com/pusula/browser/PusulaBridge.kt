package com.pusula.browser

import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject

/**
 * Yeni sekme sayfasının ("Pusula" adıyla) okuduğu küçük köprü.
 * [trusted] yalnızca kendi sayfamız yüklüyken true olur; dış siteler hiçbir şey okuyamaz.
 */
class PusulaBridge(private val prefs: Prefs) {

    @Volatile
    var trusted = false

    @JavascriptInterface
    fun config(): String {
        if (!trusted) return "{}"
        val e = Engines.get(prefs.engine)
        val arr = JSONArray()
        for (b in prefs.bookmarks().take(12)) {
            arr.put(JSONObject().put("t", b.title).put("u", b.url))
        }
        return JSONObject()
            .put("engine", e.name)
            .put("search", e.search)
            .put("bookmarks", arr)
            .toString()
    }
}
